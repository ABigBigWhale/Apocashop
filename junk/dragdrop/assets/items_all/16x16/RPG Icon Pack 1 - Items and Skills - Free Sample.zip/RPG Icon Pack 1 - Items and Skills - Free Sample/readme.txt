16x16 RPG Icons - Pack 1 - Items and Skills
Free Sample of 140 icons
by 7Soul - @7SoulDesign
http://7soul1.deviantart.com/